# CreatePlus
A Minecraft Datapack / QuiltMod for 1.18.2.

[Quilt Mod HERE](https://github.com/JieningYu/createplus-mod)

NOTE: The mod is not completed yet and it depends on this datapack.

Base compatibility enchantments for Create Fabric.

Supported Mods:
- Tech Reborn
- Farmer's Delight
- Alloy Forgery
- Applied Energistics 2
- Betternether
- Immersive Weathering
- More Ores
- Promenade
- Unearthed
- Universal Ores
- Gobber 2
- Alloygery
- Mythic Metals
- Ecologics
- Croptopia
- Architects' Palette